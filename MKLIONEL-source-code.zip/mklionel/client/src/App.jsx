import React, { useEffect, useMemo, useState } from 'react';
import { api, getToken } from './api';
import { Search, Play, Plus, Check, Menu, X, Film, LogIn, LogOut, Sparkles, ChevronRight, Clapperboard } from 'lucide-react';

const fallbackMovies = [
  {id:'nebula-run',title:'NEBULA RUN',year:2026,genre:'Sci-Fi',rating:'8.9',description:'A daring crew follows a mysterious signal beyond the edge of known space. Their discovery changes everything.',poster:'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=700',backdrop:'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=1800',featured:true,videoUrl:''},
  {id:'silent-city',title:'THE SILENT CITY',year:2025,genre:'Thriller',rating:'8.4',description:'In a city where nobody speaks, one detective hears a message that should not exist.',poster:'https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=700',backdrop:'https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=1800',videoUrl:''},
  {id:'blue-horizon',title:'BLUE HORIZON',year:2024,genre:'Adventure',rating:'8.1',description:'A deep-sea expedition discovers a world hidden beneath the waves.',poster:'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=700',backdrop:'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=1800',videoUrl:''},
  {id:'last-signal',title:'THE LAST SIGNAL',year:2026,genre:'Action',rating:'9.1',description:'One transmission. One night. One chance to stop a global catastrophe.',poster:'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=700',backdrop:'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1800',videoUrl:''},
  {id:'golden-hour',title:'GOLDEN HOUR',year:2023,genre:'Drama',rating:'7.9',description:'Two strangers take a road trip that gives them a new way to see the world.',poster:'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=700',backdrop:'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=1800',videoUrl:''},
  {id:'dark-matter',title:'DARK MATTER',year:2025,genre:'Sci-Fi',rating:'8.7',description:'A scientist finds a doorway into a reality that mirrors our own.',poster:'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?w=700',backdrop:'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?w=1800',videoUrl:''}
];

function App() {
  const [movies,setMovies] = useState(fallbackMovies);
  const [query,setQuery] = useState('');
  const [genre,setGenre] = useState('All');
  const [selected,setSelected] = useState(null);
  const [watchlist,setWatchlist] = useState([]);
  const [token,setToken] = useState(getToken());
  const [accountOpen,setAccountOpen] = useState(false);
  const [authMode,setAuthMode] = useState('login');
  const [auth,setAuth] = useState({name:'',email:'',password:''});
  const [error,setError] = useState('');
  const [toast,setToast] = useState('');

  useEffect(()=>{ api.movies().then(d=>{if(d.movies?.length)setMovies(d.movies)}).catch(()=>{}); },[]);
  useEffect(()=>{ if(token) api.watchlist().then(d=>setWatchlist(d.watchlist || [])).catch(()=>setWatchlist([])); else setWatchlist([]); },[token]);
  const genres = ['All',...new Set(movies.map(m=>m.genre).filter(Boolean))];
  const filtered = useMemo(()=>movies.filter(m=>(genre==='All'||m.genre===genre) && m.title.toLowerCase().includes(query.toLowerCase())),[movies,genre,query]);
  const featured = movies.find(m=>m.featured) || movies[0];

  function notify(message){setToast(message);setTimeout(()=>setToast(''),2600);}
  async function toggleWatchlist(movie) {
    if(!token){setAccountOpen(true);notify('Sign in to save movies');return;}
    try {
      const exists=watchlist.includes(movie.id);
      if(exists){await api.removeWatchlist(movie.id);setWatchlist(w=>w.filter(id=>id!==movie.id));notify('Removed from My List');}
      else {await api.addWatchlist(movie.id);setWatchlist(w=>[...w,movie.id]);notify('Added to My List');}
    } catch(e){notify(e.message);}
  }
  async function submitAuth(e){
    e.preventDefault();setError('');
    try {
      const result=authMode==='login' ? await api.login(auth.email,auth.password) : await api.register(auth.name,auth.email,auth.password);
      localStorage.setItem('mklionel_token',result.token);setToken(result.token);setAccountOpen(false);notify('Welcome to MKLIONEL');
    } catch(e){setError(e.message);}
  }
  function logout(){localStorage.removeItem('mklionel_token');setToken(null);setAccountOpen(false);notify('Signed out');}
  const isSaved = movie => watchlist.includes(movie.id);

  return <div className="app">
    <header className="topbar">
      <a className="brand" href="#" onClick={()=>setSelected(null)}><span className="brand-mark">M</span><span>MK<span className="brand-accent">LIONEL</span></span></a>
      <nav><a href="#home" onClick={()=>setSelected(null)}>Home</a><a href="#browse">Movies</a><a href="#my-list" onClick={()=>setGenre('All')}>My List</a></nav>
      <div className="top-actions">
        <div className="searchbox"><Search size={17}/><input value={query} onChange={e=>{setQuery(e.target.value);setSelected(null)}} placeholder="Search titles..."/></div>
        <button className="avatar" onClick={()=>setAccountOpen(true)} aria-label="Account">{token?'M':<LogIn size={18}/>}</button>
      </div>
    </header>

    {selected ? <section className="player-view">
      <button className="back-link" onClick={()=>setSelected(null)}>← Back to browse</button>
      <div className="player-frame">
        {selected.videoUrl ? <video controls autoPlay poster={selected.backdrop || selected.poster} src={selected.videoUrl}/> : <div className="video-placeholder" style={{backgroundImage:`linear-gradient(90deg,#080910 0%,transparent 100%),url(${selected.backdrop || selected.poster})`}}><Clapperboard size={46}/><h2>{selected.title}</h2><p>Video not added yet. Add an authorized video URL in the movie catalog.</p></div>}
      </div>
      <div className="detail-row"><div><span className="eyebrow">NOW PLAYING</span><h1>{selected.title}</h1><p>{selected.year} · {selected.genre} · ★ {selected.rating || 'New'}</p><p className="description">{selected.description}</p></div><button className="outline-btn" onClick={()=>toggleWatchlist(selected)}>{isSaved(selected)?<Check size={17}/>:<Plus size={17}/>} {isSaved(selected)?'In My List':'My List'}</button></div>
    </section> : <>
      <main id="home">
        <section className="hero" style={{backgroundImage:`linear-gradient(90deg,#080910 0%,rgba(8,9,16,.92) 32%,rgba(8,9,16,.28) 100%),linear-gradient(0deg,#080910 0%,transparent 40%),url(${featured?.backdrop || ''})`}}>
          <div className="hero-content"><div className="eyebrow"><Sparkles size={14}/> MKLIONEL ORIGINAL EXPERIENCE</div><h1>{featured?.title || 'STREAM BEYOND LIMITS'}</h1><div className="meta"><span className="rating">★ {featured?.rating || '9.0'}</span><span>{featured?.year}</span><span>{featured?.genre}</span><span className="quality">4K ULTRA HD</span></div><p>{featured?.description}</p><div className="hero-buttons"><button className="primary-btn" onClick={()=>setSelected(featured)}><Play size={18} fill="currentColor"/> Play now</button><button className="secondary-btn" onClick={()=>toggleWatchlist(featured)}>{isSaved(featured)?<Check size={18}/>:<Plus size={18}/>} My List</button></div></div>
          <div className="hero-label">FEATURED TITLE <span>01 / 06</span></div>
        </section>

        <section className="browse-section" id="browse">
          <div className="section-heading"><div><span className="eyebrow">CURATED FOR YOU</span><h2>Explore movies</h2></div><span className="result-count">{filtered.length} TITLES</span></div>
          <div className="genre-row">{genres.map(g=><button key={g} className={genre===g?'genre active':'genre'} onClick={()=>setGenre(g)}>{g}</button>)}</div>
          <div className="movie-grid">{filtered.map(movie=><article className="movie-card" key={movie.id}>
            <button className="poster-button" onClick={()=>setSelected(movie)}><img src={movie.poster} alt={`${movie.title} poster`} loading="lazy"/><span className="poster-play"><Play fill="currentColor" size={20}/></span></button>
            <div className="movie-info"><div><h3>{movie.title}</h3><p>{movie.year} · {movie.genre}</p></div><button className="save-icon" onClick={()=>toggleWatchlist(movie)} aria-label="Save movie">{isSaved(movie)?<Check size={18}/>:<Plus size={18}/>}</button></div>
          </article>)}</div>
          {filtered.length===0 && <div className="empty">No titles found. Try another search.</div>}
        </section>

        <section className="my-list-section" id="my-list"><div className="section-heading"><div><span className="eyebrow">YOUR COLLECTION</span><h2>My List</h2></div></div><div className="list-strip">{movies.filter(isSaved).length ? movies.filter(isSaved).map(m=><button key={m.id} className="list-chip" onClick={()=>setSelected(m)}><img src={m.poster}/><span>{m.title}</span></button>) : <p className="muted">Save movies to find them here later. Sign in to sync your list.</p>}</div></section>
      </main>
    </>}

    <footer><div className="brand"><span className="brand-mark">M</span><span>MK<span className="brand-accent">LIONEL</span></span></div><p>Stories worth staying up for.</p><span>© {new Date().getFullYear()} MKLIONEL. Demo platform.</span></footer>

    {accountOpen && <div className="modal-backdrop" onClick={()=>setAccountOpen(false)}><div className="auth-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setAccountOpen(false)}><X/></button><span className="eyebrow">YOUR MKLIONEL ACCOUNT</span><h2>{token?'Your account':'Welcome to the experience'}</h2>{token?<><p className="muted">You are signed in. Your watchlist is synced to this account.</p><button className="primary-btn full" onClick={logout}><LogOut size={17}/> Sign out</button></>:<><div className="auth-tabs"><button className={authMode==='login'?'active':''} onClick={()=>{setAuthMode('login');setError('')}}>Sign in</button><button className={authMode==='register'?'active':''} onClick={()=>{setAuthMode('register');setError('')}}>Create account</button></div><form onSubmit={submitAuth}>{authMode==='register'&&<input required placeholder="Your name" value={auth.name} onChange={e=>setAuth({...auth,name:e.target.value})}/>}<input required type="email" placeholder="Email address" value={auth.email} onChange={e=>setAuth({...auth,email:e.target.value})}/><input required minLength="8" type="password" placeholder="Password (8+ characters)" value={auth.password} onChange={e=>setAuth({...auth,password:e.target.value})}/>{error&&<p className="error">{error}</p>}<button className="primary-btn full" type="submit">{authMode==='login'?'Sign in':'Create account'} <ChevronRight size={17}/></button></form><p className="fineprint">Demo starter: use a unique password. Never reuse your banking or email password.</p></>}</div></div>}
    {toast&&<div className="toast">{toast}</div>}
  </div>;
}
export default App;
