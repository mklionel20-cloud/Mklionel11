const API = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';
export function getToken() { return localStorage.getItem('mklionel_token'); }
async function request(path, options = {}) {
  const token = getToken();
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}
export const api = {
  movies: () => request('/movies'),
  register: (name, email, password) => request('/auth/register', { method: 'POST', body: JSON.stringify({ name, email, password }) }),
  login: (email, password) => request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  watchlist: () => request('/watchlist'),
  addWatchlist: movieId => request('/watchlist', { method: 'POST', body: JSON.stringify({ movieId }) }),
  removeWatchlist: movieId => request(`/watchlist/${movieId}`, { method: 'DELETE' })
};
