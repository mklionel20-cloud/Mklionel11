import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import { randomUUID } from 'node:crypto';
import { getDb, updateDb, getMovies } from './store.js';
import { requireAuth, makeToken } from './auth.js';

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 24) {
  console.error('Set JWT_SECRET in server/.env to a random value of at least 24 characters.');
  process.exit(1);
}
const app = express();
const port = Number(process.env.PORT || 4000);
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', (_req,res)=>res.json({ status:'ok', service:'MKLIONEL API' }));
app.get('/api/movies', async (_req,res)=>{
  try { res.json({ movies: await getMovies() }); }
  catch { res.status(500).json({ error:'Could not load movie catalog.' }); }
});

app.post('/api/auth/register', async (req,res)=>{
  const { name, email, password } = req.body || {};
  if (!name?.trim() || !email?.trim() || typeof password !== 'string' || password.length < 8)
    return res.status(400).json({ error:'Name, valid email and password (at least 8 characters) are required.' });
  const normalized = email.trim().toLowerCase();
  try {
    const user = await updateDb(async db=>{
      if (db.users.some(u=>u.email===normalized)) throw new Error('An account with this email already exists.');
      const created = { id:randomUUID(), name:name.trim().slice(0,80), email:normalized, passwordHash:await bcrypt.hash(password,12), createdAt:new Date().toISOString() };
      db.users.push(created); db.watchlists[created.id]=[];
      return { id:created.id, name:created.name, email:created.email };
    });
    res.status(201).json({ user, token:makeToken(user) });
  } catch(e) { res.status(400).json({ error:e.message || 'Could not create account.' }); }
});
app.post('/api/auth/login', async (req,res)=>{
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error:'Email and password are required.' });
  const db=await getDb();
  const user=db.users.find(u=>u.email===String(email).trim().toLowerCase());
  if (!user || !(await bcrypt.compare(password,user.passwordHash))) return res.status(401).json({ error:'Email or password is incorrect.' });
  const safe={id:user.id,name:user.name,email:user.email};
  res.json({ user:safe, token:makeToken(safe) });
});
app.get('/api/watchlist', requireAuth, async (req,res)=>{
  const db=await getDb(); res.json({ watchlist:db.watchlists[req.user.id] || [] });
});
app.post('/api/watchlist', requireAuth, async (req,res)=>{
  const { movieId }=req.body || {};
  const movies=await getMovies();
  if (!movies.some(m=>m.id===movieId)) return res.status(404).json({ error:'Movie not found.' });
  const watchlist=await updateDb(db=>{
    db.watchlists[req.user.id] ||= [];
    if (!db.watchlists[req.user.id].includes(movieId)) db.watchlists[req.user.id].push(movieId);
    return db.watchlists[req.user.id];
  });
  res.json({ watchlist });
});
app.delete('/api/watchlist/:movieId', requireAuth, async (req,res)=>{
  const watchlist=await updateDb(db=>{
    db.watchlists[req.user.id]=(db.watchlists[req.user.id] || []).filter(id=>id!==req.params.movieId);
    return db.watchlists[req.user.id];
  });
  res.json({ watchlist });
});
app.use((err,_req,res,_next)=>{ console.error(err); res.status(500).json({error:'Unexpected server error.'}); });
app.listen(port,()=>console.log(`MKLIONEL API listening on http://localhost:${port}`));
