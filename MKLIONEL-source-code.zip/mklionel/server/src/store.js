import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(here, '../data');
const dbPath = path.join(dataDir, 'db.json');
const moviesPath = path.join(dataDir, 'movies.json');
async function readDb() {
  try { return JSON.parse(await fs.readFile(dbPath, 'utf8')); }
  catch { return { users: [], watchlists: {} }; }
}
export async function updateDb(mutator) {
  await fs.mkdir(dataDir, { recursive: true });
  const db = await readDb();
  const result = await mutator(db);
  await fs.writeFile(dbPath, JSON.stringify(db, null, 2));
  return result;
}
export async function getDb() { return readDb(); }
export async function getMovies() { return JSON.parse(await fs.readFile(moviesPath, 'utf8')); }
