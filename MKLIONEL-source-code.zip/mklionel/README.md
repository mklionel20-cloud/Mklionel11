# MKLIONEL — Movie Streaming Starter

A dark, responsive movie-streaming website with a Node/Express API and an Android wrapper using Capacitor.

## Requirements
- Node.js 20+
- npm
- Android Studio (only for building the Android app)

## Run locally
1. Open a terminal in this project folder.
2. Run `npm install`.
3. Copy `server/.env.example` to `server/.env` and change `JWT_SECRET`.
4. Run `npm run dev`.
5. Open `http://localhost:5173`.

The API runs on `http://localhost:4000`.

## Demo account
Register a new account from the website. Do not use real passwords on a demo deployment.

## Add your own movies
Edit `server/data/movies.json`. Each movie can include:
- `id`, `title`, `year`, `genre`, `description`, `poster`, `backdrop`
- `videoUrl`: a URL to a video file you own or are licensed to stream
- `featured`: true/false

For local testing, place MP4 files in `server/public/videos/` and use URLs such as `/videos/sample.mp4`.
Use only movies and artwork you own, have licensed, or are otherwise authorized to distribute.

## Android build
1. Install Android Studio and the Android SDK.
2. From the project root, run `npm install`.
3. Run `npm run android:add` once to create the Android project.
4. Run `npm run android:sync` after frontend changes.
5. Open the generated `android/` folder in Android Studio.
6. Select a device/emulator and press Run.

For a real phone, configure the API base URL in `client/.env` to your deployed HTTPS API. `localhost` on an Android phone refers to the phone itself, not your computer.

## Production deployment
Deploy the client build (`client/dist`) to a static host and deploy the Express server to a Node hosting service. Set `CLIENT_ORIGIN`, `JWT_SECRET`, and `PORT` in the server environment. Use HTTPS and a persistent database before public launch.

## Current scope
Included: responsive catalog, search, genre filtering, featured title, video player page, account registration/login, JWT-protected watchlist, persistent JSON demo store, API health endpoint.

Before launch, replace the JSON demo store with a managed database, add rate limiting, email verification, password reset, moderation/admin tools, secure media storage/CDN, payment/subscription handling if needed, and legal/privacy pages.
